This tool automatically runs xml suits through soupui.

Paste it in the c drive
step 1 - set config sheet in the input folder
step 2 - run the jekins.SoapUi.vbs in the build folder

